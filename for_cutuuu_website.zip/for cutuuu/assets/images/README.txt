╔══════════════════════════════════════════════════════════════╗
║           📸 PHOTO GALLERY — HOW TO ADD YOUR PHOTOS          ║
╚══════════════════════════════════════════════════════════════╝

Your 6 real photos have already been placed in this folder!

If you ever want to REPLACE or ADD new photos, just follow this:

STEP 1: Save your photo files with these exact names:
  → photo1.jpg   (Slot 1 — lavender outfit photo)
  → photo2.jpg   (Slot 2)
  → photo3.jpg   (Slot 3)
  → photo4.jpg   (Slot 4)
  → photo5.jpg   (Slot 5)
  → photo6.jpg   (Slot 6)

STEP 2: Drop them into this folder:
  → assets/images/

STEP 3: Open index.html in your browser. That's it! ✅

TIPS:
  • JPG, PNG, and WEBP formats all work.
  • Portrait photos (phone-style) look best in the polaroid frames.
  • If a photo doesn't load, the frame shows a beautiful gradient instead.
  • To change photo captions, open script.js and edit the CONFIG object at the top.

CAPTIONS can be edited in script.js → CONFIG.photos section:
  caption: "Your caption here ❤️"

╔══════════════════════════════════════════════════════════════╗
║                     ❤️  WITH LOVE                            ║
╚══════════════════════════════════════════════════════════════╝
